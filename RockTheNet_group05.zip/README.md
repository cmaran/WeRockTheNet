WeRockTheNet
============
Group: 

Dall'Oglio Isabella
Krickl Astrid
Maran Christian
Schwertberger Bernhard

Starting the project:

Option 1:
Double Click the Run.py file and open your browser with the url: 127.0.0.1:5000

Option 2:
Use these commands in your command shell:
1.	pip install virtualenv
2.	virtualenv venv
3.	venv\Scripts\activate
4.	pip install –r requirements.txt
5.	cd src
6.	python Run.py