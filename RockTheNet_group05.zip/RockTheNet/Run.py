from Control.TemplateAccess import TemplateAccess

startTemplates = TemplateAccess()
startTemplates.registerApp()
startTemplates.run()